<h1 align = "center">🌟LILYGO T-Encoder🌟</h1>

This example needs to be used in conjunction with [T-color](https://github.com/Xinyuan-LilyGO/T-Color/tree/main/example/EspNow_test_receiver)

Esp-now broadcast example .Adjust the brightness left and right, press on and off the light







